/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package persistenciaBD;


import Dados.TipoTransacao;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class TipoTransacaoDAO {
    
	public boolean inserir(TipoTransacao tt) throws SQLException {
		
        String sql = "INSERT INTO tipotransacao (idtipotransacao, tipotransacao) VALUES (?, ?)";
        
	    try (Connection c = ConexaoBD.conectar();
	         PreparedStatement ps = c.prepareStatement(sql)) {

	       ps.setInt(1, tt.getIdTipoTransacao());
	       ps.setString(2, tt.getTipoTransacao());
	
	       return ps.executeUpdate() == 1;

       } catch (SQLException e) {
    	   System.out.println("Problema de conexao com o banco");
           e.printStackTrace();
           return false;
       }
	
	}

	public boolean excluir(int idTtransacao) {
		
		String sql = "DELETE FROM tipotransacao WHERE idtipotransacao = ?";
		
		try (Connection c = ConexaoBD.conectar();
			 PreparedStatement ps = c.prepareStatement(sql)) {
			
			ps.setInt(1, idTtransacao);
			
			return ps.executeUpdate() == 1;
			
		} catch (SQLException e) {
	                 System.out.println("Erro ao excluir tipo de transação");
	                 e.printStackTrace();
	                 return false;
	    }
		
    }

    public TipoTransacao buscarPorCodigo(int idTipo) {
    	
        String sql = "SELECT idtipotransacao, tipotransacao FROM tipotransacao WHERE idtipotransacao = ?";
        
        try (Connection c = ConexaoBD.conectar();
             PreparedStatement ps = c.prepareStatement(sql)) {
        	
        	ps.setInt(1, idTipo);
        	
        	try(ResultSet rs = ps.executeQuery();) {
        		
        		if (rs.next()) {
                    int cod = rs.getInt("idtipotransacao");
                    String tipo = rs.getString("tipotransacao");

                    return new TipoTransacao(cod, tipo);
                }
        		
        	}
        	
        	return null;
        	
	    } catch (SQLException e) {
	        System.out.println("Erro ao buscar tipo de transação");
	        e.printStackTrace();
	        return null;
	    }
        
    }

    public List<TipoTransacao> listar() {
    	
    	List<TipoTransacao> tipoTransacoes = new ArrayList<>();
    	
    	String sql = "SELECT idtipotransacao, tipotransacao FROM tipotransacao";
 
        try (Connection c = ConexaoBD.conectar();
             PreparedStatement ps = c.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {
        	
        	while (rs.next()) {
                int cod = rs.getInt("idtipotransacao");
                String tipo = rs.getString("tipotransacao");
                TipoTransacao t = new TipoTransacao(cod, tipo);
                
                tipoTransacoes.add(t);
                
            }
        	
        } catch (SQLException e) {
        	
            System.out.println("Erro ao listar agências");
            e.printStackTrace();
            
        }

        return tipoTransacoes;
    }
}
