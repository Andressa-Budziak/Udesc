/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package factory;

import dados.Administrador;
import dados.Instituicao;
import dados.Usuario;
import dados.Voluntario;

/**
 *
 * @author andre
 */


public class UsuarioFactory {
    
    public Usuario criarUsuario(String tipo, String nome, String email, String senha) {
        return switch(tipo.toUpperCase()) {
            case "VOLUNTARIO" -> criarVoluntario(nome, email, senha, null);
            case "INSTITUICAO" -> criarInstituicao(nome, email, senha, null);
            case "ADMINISTRADOR" -> criarAdministrador(nome, email, senha);
            default -> throw new IllegalArgumentException("Tipo de usuário inválido: " + tipo);
        };
    }
    
    public Voluntario criarVoluntario(String nome, String email, String senha, String cpf) {
        Voluntario voluntario = new Voluntario();
        voluntario.setNome(nome);
        voluntario.setEmail(email);
        voluntario.setSenha(senha);
        voluntario.setCpf(cpf);
        voluntario.setContatoVisivelParaInstituicoes(false);
        voluntario.setAceitouTermos(false);
        return voluntario;
    }
    
    public Instituicao criarInstituicao(String nome, String email, String senha, String cnpj) {
        Instituicao instituicao = new Instituicao();
        instituicao.setNome(nome);
        instituicao.setEmail(email);
        instituicao.setSenha(senha);
        instituicao.setCnpj(cnpj);
        instituicao.setCadastroAtivo(false);
        return instituicao;
    }
    
    public Administrador criarAdministrador(String nome, String email, String senha) {
        Administrador admin = new Administrador(nome, email, senha);
        admin.setNome(nome);
        admin.setEmail(email);
        admin.setSenha(senha);
        return admin;
    }
}