/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package dados;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author andre
 */

public class Instituicao extends Usuario {
    private String cnpj;
    private String endereco;
    private String areaAtuacao;
    private Boolean cadastroAtivo;
    private String uf;
    private String cidade;
    private String bairro;
    private List<Projeto> projetos = new ArrayList<>();
    private List<PontoColeta> pontosColeta = new ArrayList<>();

    public Instituicao() {
        super();
        this.cadastroAtivo = false;
    }

    public Instituicao(String nome, String email, String senha, String cnpj) {
        super(nome, email, senha);
        this.cnpj = cnpj;
        this.cadastroAtivo = false;
    }


    public Boolean login() {
        if (!Boolean.TRUE.equals(cadastroAtivo)) {
            System.out.println("Instituição " + nome + " não esta ativa");
            return false;
        }
        System.out.println("Instituição " + nome + " logada com sucesso");
        return true;
    }


    public Boolean atualizarCadastro() {
        this.dataAtualizacao = LocalDateTime.now();
        System.out.println("Cadastro da instituição " + nome + " atualizado");
        return true;
    }

    public List<Voluntario> buscarVoluntarios() {
        System.out.println("Buscando voluntários disponíveis");
        return List.of();
    }

    public Boolean enviarMensagemParaVoluntario(Long voluntarioId, String mensagem) {
        System.out.println("Mensagem enviada para voluntário ID: " + voluntarioId + ": " + mensagem);
        return true;
    }

    public Boolean cadastrarPontoColeta(PontoColeta pontoColeta) {
        pontosColeta.add(pontoColeta);
        System.out.println("Ponto de coleta cadastrado: " + pontoColeta.getTipoDoacao());
        return true;
    }

    public Boolean validarCNPJ() {
        if (cnpj == null || cnpj.length() != 14) {
            return false;
        }
        System.out.println("CNPJ validado: " + cnpj);
        return true;
    }

    public Boolean solicitarVoluntarios(SolicitacaoVoluntarios solicitacao) {
        System.out.println("Solicitação de voluntários criada: " + solicitacao.getTipoServico());
        return true;
    }

    public Boolean cadastrarProjeto(Projeto projeto) {
        projetos.add(projeto);
        System.out.println("Projeto cadastrado: " + projeto.getNome());
        return true;
    }

    public List<PontoColeta> getPontosColetaAtivos() {
        return pontosColeta.stream()
                .filter(PontoColeta::getAtivo)
                .toList();
    }

    public List<Projeto> getProjetosAtivos() {
        return projetos.stream()
                .filter(Projeto::getAtivo)
                .toList();
    }

    // Getters e Setters
    public String getCnpj() { return cnpj; }
    public void setCnpj(String cnpj) { this.cnpj = cnpj; }

    public String getEndereco() { return endereco; }
    public void setEndereco(String endereco) { this.endereco = endereco; }

    public String getAreaAtuacao() { return areaAtuacao; }
    public void setAreaAtuacao(String areaAtuacao) { this.areaAtuacao = areaAtuacao; }

    public Boolean getCadastroAtivo() { return cadastroAtivo; }
    public void setCadastroAtivo(Boolean cadastroAtivo) { this.cadastroAtivo = cadastroAtivo; }

    public String getUf() { return uf; }
    public void setUf(String uf) { this.uf = uf; }

    public String getCidade() { return cidade; }
    public void setCidade(String cidade) { this.cidade = cidade; }

    public String getBairro() { return bairro; }
    public void setBairro(String bairro) { this.bairro = bairro; }

    public List<Projeto> getProjetos() { return projetos; }
    public void setProjetos(List<Projeto> projetos) { this.projetos = projetos; }

    public List<PontoColeta> getPontosColeta() { return pontosColeta; }
    public void setPontosColeta(List<PontoColeta> pontosColeta) { this.pontosColeta = pontosColeta; }


}