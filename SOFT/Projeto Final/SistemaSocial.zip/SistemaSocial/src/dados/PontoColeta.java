/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package dados;

import java.time.LocalDate;

/**
 *
 * @author andre
 */


public class PontoColeta {
    private Long id;
    private String tipoDoacao;
    private Integer quantidade;
    private String prioridade;
    private LocalDate prazo;
    private Boolean ativo;

    public PontoColeta() {
        this.ativo = true;
    }

    public PontoColeta(String tipoDoacao, Integer quantidade, String prioridade, LocalDate prazo) {
        this();
        this.tipoDoacao = tipoDoacao;
        this.quantidade = quantidade;
        this.prioridade = prioridade;
        this.prazo = prazo;
    }

    // Getters e Setters
    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }

    public String getTipoDoacao() { return tipoDoacao; }
    public void setTipoDoacao(String tipoDoacao) { this.tipoDoacao = tipoDoacao; }

    public Integer getQuantidade() { return quantidade; }
    public void setQuantidade(Integer quantidade) { this.quantidade = quantidade; }

    public String getPrioridade() { return prioridade; }
    public void setPrioridade(String prioridade) { this.prioridade = prioridade; }

    public LocalDate getPrazo() { return prazo; }
    public void setPrazo(LocalDate prazo) { this.prazo = prazo; }

    public Boolean getAtivo() { return ativo; }
    public void setAtivo(Boolean ativo) { this.ativo = ativo; }
}
