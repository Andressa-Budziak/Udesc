/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package dados;

import java.time.LocalDateTime;

/**
 *
 * @author andre
 */

public class Notificacao {
    private Long id;
    private String tipo;
    private String mensagem;
    private LocalDateTime dataEnvio;
    private Boolean enviada;

    public Notificacao() {
        this.dataEnvio = LocalDateTime.now();
        this.enviada = false;
    }

    public Notificacao(String tipo, String mensagem) {
        this();
        this.tipo = tipo;
        this.mensagem = mensagem;
    }

    public Boolean enviarNotificacao() {
        this.enviada = true;
        System.out.println("Notificacao enviada: " + mensagem);
        return true;
    }

    // Getters e Setters
    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }

    public String getTipo() { return tipo; }
    public void setTipo(String tipo) { this.tipo = tipo; }

    public String getMensagem() { return mensagem; }
    public void setMensagem(String mensagem) { this.mensagem = mensagem; }

    public LocalDateTime getDataEnvio() { return dataEnvio; }
    public void setDataEnvio(LocalDateTime dataEnvio) { this.dataEnvio = dataEnvio; }

    public Boolean getEnviada() { return enviada; }
    public void setEnviada(Boolean enviada) { this.enviada = enviada; }
}