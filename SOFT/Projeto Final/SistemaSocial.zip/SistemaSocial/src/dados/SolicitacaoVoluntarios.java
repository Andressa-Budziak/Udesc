/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package dados;

import java.time.LocalDate;

/**
 *
 * @author andre
 */


public class SolicitacaoVoluntarios {
    private Long id;
    private String tipoServico;
    private String local;
    private LocalDate data;
    private String duracao;
    private Integer quantidadeVoluntarios;

    public SolicitacaoVoluntarios() {}

    public SolicitacaoVoluntarios(String tipoServico, String local, LocalDate data, Integer quantidadeVoluntarios) {
        this.tipoServico = tipoServico;
        this.local = local;
        this.data = data;
        this.quantidadeVoluntarios = quantidadeVoluntarios;
    }

    // Getters e Setters
    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }

    public String getTipoServico() { return tipoServico; }
    public void setTipoServico(String tipoServico) { this.tipoServico = tipoServico; }

    public String getLocal() { return local; }
    public void setLocal(String local) { this.local = local; }

    public LocalDate getData() { return data; }
    public void setData(LocalDate data) { this.data = data; }

    public String getDuracao() { return duracao; }
    public void setDuracao(String duracao) { this.duracao = duracao; }

    public Integer getQuantidadeVoluntarios() { return quantidadeVoluntarios; }
    public void setQuantidadeVoluntarios(Integer quantidadeVoluntarios) { 
        this.quantidadeVoluntarios = quantidadeVoluntarios; 
    }
}