/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package dados;

import java.time.LocalDate;

/**
 *
 * @author andre
 */



public class Projeto {
    private Long id;
    private String nome;
    private String descricao;
    private String local;
    private LocalDate data;
    private String duracao;
    private Boolean ativo;
    private String tipoServico;

    public Projeto() {
        this.ativo = true;
        this.data = LocalDate.now();
    }

    public Projeto(String nome, String descricao, String local, String tipoServico) {
        this();
        this.nome = nome;
        this.descricao = descricao;
        this.local = local;
        this.tipoServico = tipoServico;
    }

    public Boolean atualizarInformacoes() {
        System.out.println("Informações do projeto " + nome + " atualizadas");
        return true;
    }

    public Boolean ativarProjeto() {
        this.ativo = true;
        System.out.println("Projeto " + nome + " ativado");
        return true;
    }

    public Boolean desativarProjeto() {
        this.ativo = false;
        System.out.println("Projeto " + nome + " desativado");
        return true;
    }

    // Getters e Setters
    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }

    public String getNome() { return nome; }
    public void setNome(String nome) { this.nome = nome; }

    public String getDescricao() { return descricao; }
    public void setDescricao(String descricao) { this.descricao = descricao; }

    public String getLocal() { return local; }
    public void setLocal(String local) { this.local = local; }

    public LocalDate getData() { return data; }
    public void setData(LocalDate data) { this.data = data; }

    public String getDuracao() { return duracao; }
    public void setDuracao(String duracao) { this.duracao = duracao; }

    public Boolean getAtivo() { return ativo; }
    public void setAtivo(Boolean ativo) { this.ativo = ativo; }

    public String getTipoServico() { return tipoServico; }
    public void setTipoServico(String tipoServico) { this.tipoServico = tipoServico; }
}