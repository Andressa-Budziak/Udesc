/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package dados;

import java.time.LocalDateTime;

/**
 *
 * @author andre
 */

public class Administrador extends Usuario {

    public Administrador(String nome1, String email1, String senha1) {
        super();
    }

    public Administrador(String nome, String email, String senha, String senha1) {
        super(nome, email, senha);
    }


    public Boolean login() {
        System.out.println("Administrador " + nome + " logado com sucesso");
        return true;
    }


    public Boolean atualizarCadastro() {
        this.dataAtualizacao = LocalDateTime.now();
        System.out.println("Cadastro do administrador atualizado");
        return true;
    }

    public Boolean ativarCadastroInstituicao(Long instituicaoId) {
        System.out.println("Ativando cadastro da instituição ID: " + instituicaoId);
        return true;
    }

    public Boolean editarCadastroUsuario(Long usuarioId) {
        System.out.println("Editando cadastro do usuário ID: " + usuarioId);
        return true;
    }

    public Boolean excluirCadastroUsuario(Long usuarioId) {
        System.out.println("Excluindo cadastro do usuário ID: " + usuarioId);
        return true;
    }
}

