/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package dados;

/**
 *
 * @author andre
 */

public class OfertaVoluntariado {
    private Long id;
    private String tipoServico;
    private String disponibilidade;
    private String regiao;
    private Boolean ativa;

    public OfertaVoluntariado() {
        this.ativa = true;
    }

    public OfertaVoluntariado(String tipoServico, String disponibilidade, String regiao) {
        this();
        this.tipoServico = tipoServico;
        this.disponibilidade = disponibilidade;
        this.regiao = regiao;
    }

    // Getters e Setters
    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }

    public String getTipoServico() { return tipoServico; }
    public void setTipoServico(String tipoServico) { this.tipoServico = tipoServico; }

    public String getDisponibilidade() { return disponibilidade; }
    public void setDisponibilidade(String disponibilidade) { this.disponibilidade = disponibilidade; }

    public String getRegiao() { return regiao; }
    public void setRegiao(String regiao) { this.regiao = regiao; }

    public Boolean getAtiva() { return ativa; }
    public void setAtiva(Boolean ativa) { this.ativa = ativa; }
}
