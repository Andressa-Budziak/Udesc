/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package dados;

import java.time.LocalDateTime;
import java.util.List;

/**
 *
 * @author andre
 */

public class Mensagem {
    private Long id;
    private String texto;
    private LocalDateTime dataHora;
    private Long remetenteId;
    private Long destinatarioId;
    private Boolean contatoPermitido;

    public Mensagem() {
        this.dataHora = LocalDateTime.now();
        this.contatoPermitido = true;
    }

    public Mensagem(String texto, Long remetenteId, Long destinatarioId) {
        this();
        this.texto = texto;
        this.remetenteId = remetenteId;
        this.destinatarioId = destinatarioId;
    }

    public Boolean enviar() {
        System.out.println("Mensagem enviada de " + remetenteId + " para " + destinatarioId);
        return true;
    }

    public List<Mensagem> getHistoricoMensagens(Long usuarioId) {
        System.out.println("Buscando historico de mensagens para usuorio ID: " + usuarioId);
        return List.of();
    }

    // Getters e Setters
    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }

    public String getTexto() { return texto; }
    public void setTexto(String texto) { this.texto = texto; }

    public LocalDateTime getDataHora() { return dataHora; }
    public void setDataHora(LocalDateTime dataHora) { this.dataHora = dataHora; }

    public Long getRemetenteId() { return remetenteId; }
    public void setRemetenteId(Long remetenteId) { this.remetenteId = remetenteId; }

    public Long getDestinatarioId() { return destinatarioId; }
    public void setDestinatarioId(Long destinatarioId) { this.destinatarioId = destinatarioId; }

    public Boolean getContatoPermitido() { return contatoPermitido; }
    public void setContatoPermitido(Boolean contatoPermitido) { this.contatoPermitido = contatoPermitido; }
}