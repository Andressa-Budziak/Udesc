/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package dados;

/**
 *
 * @author andre
 */
import java.util.ArrayList;
import java.util.List;


public class Catalogo {
    private String filtros;
    private List<Instituicao> instituicoes = new ArrayList<>();

    public Catalogo() {}

    public List<Instituicao> buscarTodasInstituicoes() {
        System.out.println("Buscando todas as instituicoes cadastradas");
        return instituicoes;
    }

    public List<Instituicao> buscarInstituicoesPorNome(String nome) {
        System.out.println("Buscando instituicoes por nome: " + nome);
        return List.of();
    }

    public List<Instituicao> buscarInstituicoesComProjetos() {
        System.out.println("Buscando instituicoes com projetos ativos");
        return List.of();
    }

    public List<Instituicao> buscarInstituicoesComPontosColeta() {
        System.out.println("Buscando instituicoes com pontos de coleta ativos");
        return List.of();
    }

    public List<Projeto> buscarProjetosAtivos() {
        System.out.println("Buscando todos os projetos ativos");
        return List.of();
    }

    public List<PontoColeta> buscarPontosColetaAtivos() {
        System.out.println("Buscando todos os pontos de coleta ativos");
        return List.of();
    }
    
    public void adicionarInstituicao(Instituicao i) {
        instituicoes.add(i);
    }


    // Getters e Setters
    public String getFiltros() { return filtros; }
    public void setFiltros(String filtros) { this.filtros = filtros; }
}