package dados;

import java.time.LocalDateTime;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author andre
 */


public class Voluntario extends Usuario {
    private String cpf;
    private String disponibilidade;
    private String regiaoPreferencia;
    private String diasSemana;
    private String preferenciaHorario;
    private String tipoServico;
    private Boolean aceitouTermos;
    private Boolean contatoVisivelParaInstituicoes;

    public Voluntario() {
        super();
        this.contatoVisivelParaInstituicoes = false;
    }

    public Voluntario(String nome, String email, String senha, String cpf) {
        super(nome, email, senha);
        this.cpf = cpf;
        this.contatoVisivelParaInstituicoes = false;
    }


    public Boolean login() {
        System.out.println("Voluntário " + nome + " logado com sucesso");
        return true;
    }


    public Boolean atualizarCadastro() {
        this.dataAtualizacao = LocalDateTime.now();
        System.out.println("Cadastro do voluntário " + nome + " atualizado");
        return true;
    }

    public Map<String, Object> getPerfilInstituicoes() {
        Map<String, Object> perfil = new HashMap<>();
        perfil.put("id", this.id);
        perfil.put("nome", this.nome);
        perfil.put("disponibilidade", this.disponibilidade);
        perfil.put("regiaoPreferencia", this.regiaoPreferencia);
        perfil.put("diasSemana", this.diasSemana);
        perfil.put("preferenciaHorario", this.preferenciaHorario);
        perfil.put("tipoServico", this.tipoServico);
        
        if (Boolean.TRUE.equals(contatoVisivelParaInstituicoes)) {
            perfil.put("email", this.email);
            perfil.put("telefone", this.telefone);
        } else {
            perfil.put("email", "Contato via plataforma");
            perfil.put("telefone", "Contato via plataforma");
        }
        
        return perfil;
    }

    public Boolean isContatoVisivel() {
        return contatoVisivelParaInstituicoes;
    }

    public Boolean cadastrarOfertaVoluntariado(OfertaVoluntariado oferta) {
        System.out.println("Oferta de voluntariado cadastrada: " + oferta.getTipoServico());
        return true;
    }

    public List<Projeto> buscarProjetosAtivos() {
        System.out.println("Buscando projetos ativos para o voluntário");
        return List.of();
    }

    public Boolean atualizarDisponibilidade() {
        this.dataAtualizacao = LocalDateTime.now();
        System.out.println("Disponibilidade do voluntário " + nome + " atualizada");
        return true;
    }

    // Getters e Setters
    public String getCpf() { return cpf; }
    public void setCpf(String cpf) { this.cpf = cpf; }

    public String getDisponibilidade() { return disponibilidade; }
    public void setDisponibilidade(String disponibilidade) { this.disponibilidade = disponibilidade; }

    public String getRegiaoPreferencia() { return regiaoPreferencia; }
    public void setRegiaoPreferencia(String regiaoPreferencia) { this.regiaoPreferencia = regiaoPreferencia; }

    public String getDiasSemana() { return diasSemana; }
    public void setDiasSemana(String diasSemana) { this.diasSemana = diasSemana; }

    public String getPreferenciaHorario() { return preferenciaHorario; }
    public void setPreferenciaHorario(String preferenciaHorario) { this.preferenciaHorario = preferenciaHorario; }

    public String getTipoServico() { return tipoServico; }
    public void setTipoServico(String tipoServico) { this.tipoServico = tipoServico; }

    public Boolean getAceitouTermos() { return aceitouTermos; }
    public void setAceitouTermos(Boolean aceitouTermos) { this.aceitouTermos = aceitouTermos; }

    public Boolean getContatoVisivelParaInstituicoes() { return contatoVisivelParaInstituicoes; }
    public void setContatoVisivelParaInstituicoes(Boolean contatoVisivelParaInstituicoes) { 
        this.contatoVisivelParaInstituicoes = contatoVisivelParaInstituicoes; 
    }


}