/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package dados;

import java.time.LocalDateTime;
import java.util.Objects;


public abstract class Usuario {
    protected Long id;
    protected String nome;
    protected String email;
    protected String telefone;
    protected String senha;
    protected Boolean ativo;
    protected Boolean notificacoesAtivas;
    protected LocalDateTime dataCriacao;
    protected LocalDateTime dataAtualizacao;

    public Usuario() {
        this.dataCriacao = LocalDateTime.now();
        this.ativo = true;
        this.notificacoesAtivas = true;
    }

    public Usuario(String nome, String email, String senha) {
        this();
        this.nome = nome;
        this.email = email;
        this.senha = senha;
    }

    // Métodos concretos implementados na classe base
    public Boolean login(String senhaDigitada) {
        if (this.senha.equals(senhaDigitada) && Boolean.TRUE.equals(ativo)) {
            System.out.println("Login realizado com sucesso para: " + nome);
            return true;
        }
        return false;
    }
    
    public Boolean atualizarCadastro(String novoEmail, String novoTelefone) {
        if (novoEmail != null && !novoEmail.isEmpty()) {
            this.email = novoEmail;
        }
        if (novoTelefone != null && !novoTelefone.isEmpty()) {
            this.telefone = novoTelefone;
        }
        this.dataAtualizacao = LocalDateTime.now();
        System.out.println("Cadastro atualizado para: " + nome);
        return true;
    }
    
    public void logout() {
        System.out.println("Usuário " + nome + " realizou logout");
    }
    
    public void desativarConta() {
        this.ativo = false;
        this.dataAtualizacao = LocalDateTime.now();
        System.out.println("Conta desativada: " + nome);
    }
    
    public void ativarConta() {
        this.ativo = true;
        this.dataAtualizacao = LocalDateTime.now();
        System.out.println("Conta ativada: " + nome);
    }
    
    public void alterarSenha(String novaSenha) {
        this.senha = novaSenha;
        this.dataAtualizacao = LocalDateTime.now();
        System.out.println("Senha alterada para: " + nome);
    }

    // Getters e Setters
    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }

    public String getNome() { return nome; }
    public void setNome(String nome) { this.nome = nome; }

    public String getEmail() { return email; }
    public void setEmail(String email) { this.email = email; }

    public String getTelefone() { return telefone; }
    public void setTelefone(String telefone) { this.telefone = telefone; }

    public String getSenha() { return senha; }
    public void setSenha(String senha) { this.senha = senha; }

    public Boolean getAtivo() { return ativo; }
    public void setAtivo(Boolean ativo) { this.ativo = ativo; }

    public Boolean getNotificacoesAtivas() { return notificacoesAtivas; }
    public void setNotificacoesAtivas(Boolean notificacoesAtivas) { this.notificacoesAtivas = notificacoesAtivas; }

    public LocalDateTime getDataCriacao() { return dataCriacao; }
    public void setDataCriacao(LocalDateTime dataCriacao) { this.dataCriacao = dataCriacao; }

    public LocalDateTime getDataAtualizacao() { return dataAtualizacao; }
    public void setDataAtualizacao(LocalDateTime dataAtualizacao) { this.dataAtualizacao = dataAtualizacao; }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Usuario usuario = (Usuario) o;
        return Objects.equals(id, usuario.id) && Objects.equals(email, usuario.email);
    }

    @Override
    public int hashCode() {
        return Objects.hash(id, email);
    }
    
    @Override
    public String toString() {
        return "Usuario{" +
               "id=" + id +
               ", nome='" + nome + '\'' +
               ", email='" + email + '\'' +
               ", ativo=" + ativo +
               '}';
    }
}