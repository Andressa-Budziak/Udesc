/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package sistemasocial;

import dados.Administrador;
import dados.Catalogo;
import dados.Instituicao;
import dados.PontoColeta;
import dados.Projeto;
import dados.Usuario;
import dados.Voluntario;
import factory.UsuarioFactory;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Scanner;
/**
 *
 * @author andre
 */
public class SistemaSocial {
    
    private static Map<String, Usuario> mapaUsuarios = new HashMap<>();
    private static List<Usuario> usuarios = new ArrayList<>();
    private static List<Instituicao> instituicoes = new ArrayList<>();
    private static List<Voluntario> voluntarios = new ArrayList<>();
    private static List<Administrador> administradores = new ArrayList<>();
    private static List<Projeto> projetos = new ArrayList<>();
    private static List<PontoColeta> pontosColeta = new ArrayList<>();
    private static UsuarioFactory usuarioFactory = new UsuarioFactory();
    private static Scanner scanner = new Scanner(System.in);
    private static Usuario usuarioLogado = null;
    private static Usuario usuario;

    public static void main(String[] args) {
        MenuPrincipal();
    }
    
    private static void MenuPrincipal() {
        int opcao;
        do {
            System.out.println("\n=== SISTEMA SOCIAL - ACAO SOLIDARIA ===");
            System.out.println("1. Login");
            System.out.println("2. Cadastrar Usuario");
            System.out.println("3. Listar Catalogo de Instituicoes");
            System.out.println("4. Listar Todos os Cadastros");
            System.out.println("0. Sair");
            System.out.print("Escolha uma opcao: ");
            
            opcao = scanner.nextInt();
            scanner.nextLine();
            
            switch (opcao) {
                case 1 -> fazerLogin();
                case 2 -> cadastrarUsuario(usuario);
                case 3 -> listarCatalogoInstituicoes();
                case 4 -> listarTodosCadastros();
                case 0 -> System.out.println("Saindo do sistema...");
                default -> System.out.println("Opcao invalida!");
            }
        } while (opcao != 0);
    }
    
    
    // VOLUNTARIOS
    
    private static void menuVoluntario(Voluntario voluntario) {
        int opcao;
        do {
            System.out.println("\n=== MENU VOLUNTARIO ===");
            System.out.println("Usuário: " + voluntario.getNome());
            System.out.println("1. Atualizar disponibilidade  ");
            System.out.println("2. Alterar visibilidade do contato ");
            System.out.println("3. Ver catalogo de instituicoes  ");
            System.out.println("4. Atualizar cadastro  ");
            System.out.println("0. Logout  ");
            System.out.print("Escolha uma opcao: ");
            
            opcao = scanner.nextInt();
            scanner.nextLine();
            
            switch (opcao) {
                case 1 -> atualizarDisponibilidade(voluntario);
                case 2 -> alterarVisibilidadeContato(voluntario);
                case 3 -> listarCatalogoInstituicoes();
                case 4 -> atualizarCadastroVoluntario(voluntario);
                case 0 -> {
                    System.out.println("Logout realizado com sucesso!");
                    usuarioLogado = null;
                }
                default -> System.out.println("Opcao invalida! ");
            }
        } while (opcao != 0 && usuarioLogado != null);
    }
    
    private static void atualizarCadastroVoluntario(Voluntario voluntario) {
        System.out.println("\n=== ATUALIZAR CADASTRO ===  ");
        System.out.print("Novo telefone (atual: " + voluntario.getTelefone() + "): ");
        String telefone = scanner.nextLine();
        if (!telefone.isEmpty()) voluntario.setTelefone(telefone);
        
        System.out.print("Nova regiao de preferencia (atual: " + voluntario.getRegiaoPreferencia() + "): ");
        String regiao = scanner.nextLine();
        if (!regiao.isEmpty()) voluntario.setRegiaoPreferencia(regiao);
        
        System.out.println("Cadastro atualizado com sucesso! ");
    }
    
    private static void alterarVisibilidadeContato(Voluntario voluntario) {
        System.out.println("\n=== ALTERAR VISIBILIDADE DO CONTATO ===  ");
        System.out.println("Atualmente seu contato esta: " + 
                          (voluntario.isContatoVisivel() ? "VISiVEL" : "OCULTO") + 
                          " para instituicoes");
        
        System.out.print("Deseja alterar? (sim/nao): ");
        String resposta = scanner.nextLine();
        
        if (resposta.equalsIgnoreCase("sim")) {
            boolean novaVisibilidade = !voluntario.isContatoVisivel();
            voluntario.setContatoVisivelParaInstituicoes(novaVisibilidade);
            System.out.println("Visibilidade alterada para: " + 
                              (novaVisibilidade ? "VISIVEL" : "OCULTO"));
        }
    }
    
    private static void atualizarDisponibilidade(Voluntario voluntario) {
        System.out.println("\n=== ATUALIZAR DISPONIBILIDADE ===  ");
        System.out.print("Nova disponibilidade: ");
        String disponibilidade = scanner.nextLine();
        
        System.out.print("Novos dias da semana: ");
        String diasSemana = scanner.nextLine();
        
        System.out.print("Novo horario preferencial: ");
        String preferenciaHorario = scanner.nextLine();
        
        voluntario.setDisponibilidade(disponibilidade);
        voluntario.setDiasSemana(diasSemana);
        voluntario.setPreferenciaHorario(preferenciaHorario);
        
        System.out.println("Disponibilidade atualizada com sucesso! ");
    }
    
    
   //INSTITUICOES
    
    private static void menuInstituicao(Instituicao instituicao) {
        int opcao;
        do {
            System.out.println("\n=== MENU INSTITUIÇÃO ===  ");
            System.out.println("Instituição: " + instituicao.getNome());
            System.out.println("Status: " + (instituicao.getCadastroAtivo() ? "ATIVA" : "AGUARDANDO ATIVAÇÃO"));
            System.out.println("1. Cadastrar novo projeto  ");
            System.out.println("2. Cadastrar ponto de coleta  ");
            System.out.println("3. Atualizar cadastro  ");
            System.out.println("0. Logout  ");
            System.out.print("Escolha uma opção: ");
            
            opcao = scanner.nextInt();
            scanner.nextLine();
            
            switch (opcao) {
                case 1 -> cadastrarProjetoParaInstituicao(instituicao);
                case 2 -> cadastrarPontoColetaParaInstituicao(instituicao);
                case 3 -> atualizarCadastroInstituicao(instituicao);
                case 0 -> {
                    System.out.println("Logout realizado com sucesso!");
                    usuarioLogado = null;
                }
                default -> System.out.println("Opcao invalida!");
            }
        } while (opcao != 0 && usuarioLogado != null);
    }
    
    private static void cadastrarProjetoParaInstituicao(Instituicao instituicao) {
        if (!instituicao.getCadastroAtivo()) {
            System.out.println("Instituicao nao esta ativa. Nao e possivel cadastrar projetos");
            return;
        }
        
        System.out.println("\n=== CADASTRAR NOVO PROJETO ===");
        System.out.print("Nome do Projeto:");
        String nome = scanner.nextLine();
        
        System.out.print("Descricao:");
        String descricao = scanner.nextLine();
        
        System.out.print("Local de realizacao: ");
        String local = scanner.nextLine();
        
        System.out.print("Tipo de Servico: ");
        String tipoServico = scanner.nextLine();
        
        System.out.print("Duracao estimada: ");
        String duracao = scanner.nextLine();
        
        Projeto projeto = new Projeto(nome, descricao, local, tipoServico);
        projeto.setDuracao(duracao);
        
        instituicao.cadastrarProjeto(projeto);
        projetos.add(projeto);
        
        System.out.println("Projeto cadastrado com sucesso! ");
    }
    
    private static void cadastrarPontoColetaParaInstituicao(Instituicao instituicao) {
        if (!instituicao.getCadastroAtivo()) {
            System.out.println("Instituicao nao esta ativa. Nao e possivel cadastrar pontos de coleta ");
            return;
        }
        
        System.out.println("\n=== CADASTRAR PONTO DE COLETA ===  ");
        System.out.print("Tipo de Doacao:  ");
        String tipoDoacao = scanner.nextLine();
        
        System.out.print("Quantidade necessaria: ");
        Integer quantidade = scanner.nextInt();
        scanner.nextLine();
        
        System.out.print("Prioridade (BAIXA, MEDIA, ALTA, URGENTE):  ");
        String prioridade = scanner.nextLine();
        
        System.out.print("Prazo final (AAAAMMDD): ");
        String prazoStr = scanner.nextLine();
        LocalDate prazo = LocalDate.parse(prazoStr);
        
        PontoColeta pontoColeta = new PontoColeta(tipoDoacao, quantidade, prioridade, prazo);
        
        instituicao.cadastrarPontoColeta(pontoColeta);
        pontosColeta.add(pontoColeta);
        
        System.out.println("Ponto de coleta cadastrado com sucesso!");
    }
    
    private static void atualizarCadastroInstituicao(Instituicao instituicao) {
        System.out.println("\n=== ATUALIZAR CADASTRO ===  ");
        System.out.print("Novo telefone (atual: " + instituicao.getTelefone() + "): ");
        String telefone = scanner.nextLine();
        if (!telefone.isEmpty()) instituicao.setTelefone(telefone);
        
        System.out.print("Novo endereço (atual: " + instituicao.getEndereco() + "): ");
        String endereco = scanner.nextLine();
        if (!endereco.isEmpty()) instituicao.setEndereco(endereco);
        
        System.out.print("Nova area de atuacao (atual: " + instituicao.getAreaAtuacao() + "): ");
        String area = scanner.nextLine();
        if (!area.isEmpty()) instituicao.setAreaAtuacao(area);
        
        System.out.println("Cadastro atualizado com sucesso!");
    }
    
    // LOGIN USUARIO
    

    private static void fazerLogin() {
        System.out.println("\n=== LOGIN ===");
        
        System.out.print("Email: ");
        String email = scanner.nextLine();
        
        System.out.print("Senha: ");
        String senha = scanner.nextLine();
        
        boolean loginSucesso = loginUsuario(email, senha);
        
        if (loginSucesso && usuarioLogado != null) {
            // Abre menu específico baseado no tipo de usuário
            if (usuarioLogado instanceof Voluntario voluntario) {
                menuVoluntario(voluntario);
            } else if (usuarioLogado instanceof Instituicao instituicao) {
                menuInstituicao(instituicao);
            } else if (usuarioLogado instanceof Administrador administrador) {
                menuAdministrador(administrador);
            }
        }
    }
    
    //Metodo de validação do login
    public static boolean loginUsuario(String email, String senha) {
        Usuario verificacao = mapaUsuarios.get(email);
        
        if (verificacao != null) {
            // Verifica o login da classe usuario
            boolean loginSucesso = verificacao.login(senha);
            
            if (loginSucesso) {
                usuarioLogado = verificacao;
                System.out.println("\nBemvindo, " + verificacao.getNome() + "!");
                System.out.println("Tipo de conta" + verificacao.getClass().getSimpleName());
                
                // Verificacao de tipo de usuario
                if (verificacao instanceof Instituicao instituicao) {
                    if (!instituicao.getCadastroAtivo()) {
                        System.out.println("ATENCAO: Seu cadastro esta aguardando ativacao por um administrador");
                    }
                }
                return true;
            } else {
                if (!verificacao.getAtivo()) {
                    System.out.println("Conta desativada. Entre em contato com o administrador");
                } else {
                    System.out.println("Senha incorreta!");
                }
                return false;
            }
        } else {
            System.out.println("Usuario nao encontrado!");
            System.out.println("Por favor, cadastre-se no sistema");
            return false;
        }
    }
    
    
// TESTES
    static void cadastrarAdministradorTeste(String nome, String email, String telefone, String senha) {
    Administrador admin = new Administrador(nome, email, senha);
    if (telefone != null) admin.setTelefone(telefone);
    usuarios.add(admin);
    administradores.add(admin);
    mapaUsuarios.put(email, admin);

    }


    static void cadastrarVoluntarioTeste(String nome, String email, String telefone, String senha, String cpf) {
        Voluntario v = new Voluntario(nome, email, senha, cpf);
        registrarUsuarioEmColecoes(v);
    }

    static void cadastrarInstituicaoTeste(String nome, String email, String telefone, String senha, String cnpj) {
        Instituicao i = new Instituicao(nome, email, senha, cnpj);
        registrarUsuarioEmColecoes(i);
    }
    
    static void cadastrarUsuarioTeste(String nome, String email, String telefone, String senha, int tipoOpcao) {
        switch (tipoOpcao) {
            case 1 -> cadastrarVoluntarioTeste(nome, email, telefone, senha, "000.000.000-00");
            case 2 -> cadastrarInstituicaoTeste(nome, email, telefone, senha, "00.000.000/0000-00");
            case 3 -> cadastrarAdministradorTeste(nome, email, telefone, senha);
            default -> throw new IllegalArgumentException("Tipo de conta inválido!");
        }
    }

    
    private static void registrarUsuarioEmColecoes(Usuario u) {
    if (u == null) return;
    // adiciona na lista genérica de todos os usuários
    usuarios.add(u);
    // adiciona no mapa usando e-mail como chave (sobrescreve se já existir)
    if (u.getEmail() != null) {
        mapaUsuarios.put(u.getEmail(), u);
    }
    // adiciona nas listas específicas por tipo
    if (u instanceof Administrador) {
        administradores.add((Administrador) u);
    } else if (u instanceof Instituicao) {
        instituicoes.add((Instituicao) u);
    } else if (u instanceof Voluntario) {
        voluntarios.add((Voluntario) u);
    }
}

        // USUARIO
    static void cadastrarUsuario(Usuario usuario) {
        System.out.println("\n=== CADASTRO DE USUARIO ===");
        
        // Dados básicos comuns a todos os usuários
        System.out.print("Nome: ");
        String nome = scanner.nextLine();
        
        System.out.print("Email: ");
        String email = scanner.nextLine();
        
        System.out.print("Telefone: ");
        String telefone = scanner.nextLine();
        
        System.out.print("Senha: ");
        String senha = scanner.nextLine();
        
        // Seleção do tipo de conta
        System.out.println("\nSelecione o tipo de conta:");
        System.out.println("1. Voluntario");
        System.out.println("2. Instituicao");
        System.out.println("3. Administrador");
        System.out.print("Opcao: ");
        
        int tipoOpcao = scanner.nextInt();
        scanner.nextLine(); // Limpar buffer
        
        switch (tipoOpcao) {
            case 1 -> cadastrarVoluntario(nome, email, telefone, senha);
            case 2 -> cadastrarInstituicao(nome, email, telefone, senha);
            case 3 -> cadastrarAdministrador(nome, email, telefone, senha);
            default -> System.out.println("Tipo de conta invalido!");
        }
    }
    
    private static void cadastrarVoluntario(String nome, String email, String telefone, String senha) {
        System.out.println("\n=== DADOS DO VOLUNTARIO ===");
        
        System.out.print("CPF: ");
        String cpf = scanner.nextLine();
        
        System.out.print("Disponibilidade (ex: Finais de semana, Tarde): ");
        String disponibilidade = scanner.nextLine();
        
        System.out.print("Regiao de Preferencia: ");
        String regiaoPreferencia = scanner.nextLine();
        
        System.out.print("Dias da Semana disponiveis: ");
        String diasSemana = scanner.nextLine();
        
        System.out.print("Preferencia de Horario: ");
        String preferenciaHorario = scanner.nextLine();
        
        System.out.print("Tipo de Serviço que pode oferecer: ");
        String tipoServico = scanner.nextLine();
        
        System.out.print("Aceitou os termos? (true/false): ");
        Boolean aceitouTermos = scanner.nextBoolean();
        scanner.nextLine();
        
        System.out.print("Contato visivel para instituicoes? (true/false): ");
        Boolean contatoVisivel = scanner.nextBoolean();
        scanner.nextLine();
        
        Voluntario voluntario = usuarioFactory.criarVoluntario(nome, email, senha, cpf);
        voluntario.setTelefone(telefone);
        voluntario.setDisponibilidade(disponibilidade);
        voluntario.setRegiaoPreferencia(regiaoPreferencia);
        voluntario.setDiasSemana(diasSemana);
        voluntario.setPreferenciaHorario(preferenciaHorario);
        voluntario.setTipoServico(tipoServico);
        voluntario.setAceitouTermos(aceitouTermos);
        voluntario.setContatoVisivelParaInstituicoes(contatoVisivel);
        
        voluntarios.add(voluntario);
        usuarios.add(voluntario);
        
        System.out.println("Voluntario cadastrado com sucesso!");
        System.out.println("Perfil disponível para instituições: " + (contatoVisivel ? "SIM" : "NÃO"));
    }
    
    private static void cadastrarInstituicao(String nome, String email, String telefone, String senha) {
        System.out.println("\n=== DADOS DA INSTITUIÇÃO ===");
        
        System.out.print("CNPJ: ");
        String cnpj = scanner.nextLine();
        
        System.out.print("Area de Atuacao: ");
        String areaAtuacao = scanner.nextLine();
        
        System.out.print("Endereco completo: ");
        String endereco = scanner.nextLine();
        
        System.out.print("UF: ");
        String uf = scanner.nextLine();
        
        System.out.print("Cidade: ");
        String cidade = scanner.nextLine();
        
        System.out.print("Bairro: ");
        String bairro = scanner.nextLine();
        
        System.out.print("Ativar cadastro agora? (true/false): ");
        Boolean cadastroAtivo = scanner.nextBoolean();
        scanner.nextLine();
        
        Instituicao instituicao = usuarioFactory.criarInstituicao(nome, email, senha, cnpj);
        instituicao.setTelefone(telefone);
        instituicao.setAreaAtuacao(areaAtuacao);
        instituicao.setEndereco(endereco);
        instituicao.setUf(uf);
        instituicao.setCidade(cidade);
        instituicao.setBairro(bairro);
        instituicao.setCadastroAtivo(cadastroAtivo);
        
        instituicoes.add(instituicao);
        usuarios.add(instituicao);
        
        System.out.println("Instituicao cadastrada com sucesso!");
        System.out.println("Status: " + (cadastroAtivo ? "ATIVA" : "AGUARDANDO ATIVACAO"));
        
        if (!cadastroAtivo) {
            System.out.println("O cadastro precisa ser ativado por um administrador para acessar o sistema.");
        }
    }
    
    private static void cadastrarAdministrador(String nome, String email, String telefone, String senha) {
        System.out.println("\n=== DADOS DO ADMINISTRADOR ===");
        
        System.out.print("Confirme a senha para criacao de administrador: ");
        String confirmacaoSenha = scanner.nextLine();
        
        if (!senha.equals(confirmacaoSenha)) {
            System.out.println("Senhas nao coincidem! Cadastro cancelado.");
            return;
        }
        
        Administrador administrador = usuarioFactory.criarAdministrador(nome, email, senha);
        administrador.setTelefone(telefone);
        
        administradores.add(administrador);
        usuarios.add(administrador);
        
        System.out.println("Administrador cadastrado com sucesso!");
        System.out.println("Agora voce pode ativar instituicoes e gerenciar usuarios.");
    }
    
   
    
    // ADMINISTRADOR
    
    private static void menuAdministrador(Administrador administrador) {
        int opcao;
        do {
            System.out.println("\n=== MENU ADMINISTRADOR === ");
            System.out.println("Administrador: " + administrador.getNome());
            System.out.println("1. Ativar instituicoes");
            System.out.println("2. Listar todos os usuarios");
            System.out.println("3. Ver instituicoes pendentes");
            System.out.println("4. Ver todos cadastros completo");
            System.out.println("5. Ver catalogo público");
            System.out.println("6. Ativar/Desativar usuários");
            
            System.out.println("0. Logout ");
            System.out.print("Escolha uma opção: ");
            
            opcao = scanner.nextInt();
            scanner.nextLine();
            
            switch (opcao) {
                case 1 -> ativarInstituicoesPendentes();
                case 2 -> listarTodosUsuarios();
                case 3 -> verInstituicoesPendentes();
                case 4 -> listarTodosCadastros();
                case 5 -> listarCatalogoInstituicoes();
                case 6 -> gerenciarStatusUsuarios();
                
                case 0 -> {
                    System.out.println("Logout realizado com sucesso!");
                    usuarioLogado = null;
                }
                default -> System.out.println("Opcao invalida!");
            }
        } while (opcao != 0 && usuarioLogado != null);
    }
    
    private static void gerenciarStatusUsuarios() {
        System.out.println("\n=== GERENCIAR STATUS DE USUARIOS ===");
        
        System.out.println("Lista de usuarios:");
        List<Usuario> listaUsuarios = new ArrayList<>(mapaUsuarios.values());
        
        for (int i = 0; i < listaUsuarios.size(); i++) {
            Usuario usuario = listaUsuarios.get(i);
            System.out.println((i + 1) + ". " + usuario.getNome() + 
                             " (" + usuario.getEmail() + ")" +
                             " - Status: " + (usuario.getAtivo() ? "Ativo" : "Inativo"));
        }
        
        System.out.print("\nSelecione o usuario (número) ou 0 para cancelar: ");
        int escolha = scanner.nextInt();
        scanner.nextLine();
        
        if (escolha > 0 && escolha <= listaUsuarios.size()) {
            Usuario usuarioSelecionado = listaUsuarios.get(escolha - 1);
            
            System.out.println("\nUsuario selecionado: " + usuarioSelecionado.getNome());
            System.out.println("Status atual: " + (usuarioSelecionado.getAtivo() ? "Ativo" : "Inativo"));
            
            System.out.print("Deseja " + (usuarioSelecionado.getAtivo() ? "desativar" : "ativar") + 
                           " esta conta? (sim/nao): ");
            String confirmacao = scanner.nextLine();
            
            if (confirmacao.equalsIgnoreCase("sim")) {
                if (usuarioSelecionado.getAtivo()) {
                    usuarioSelecionado.desativarConta();
                } else {
                    usuarioSelecionado.ativarConta();
                    
                    // Se for instituição, ativar também o cadastro específico
                    if (usuarioSelecionado instanceof Instituicao instituicao) {
                        instituicao.setCadastroAtivo(true);
                    }
                }
                System.out.println("Status atualizado com sucesso!");
            }
        }
    }
    
    private static void listarTodosUsuarios() {
        System.out.println("\n=== TODOS OS USUARIOS DO SISTEMA ===");
        System.out.println("Total: " + mapaUsuarios.size() + " usuarios");
        
        int countVoluntarios = 0;
        int countInstituicoes = 0;
        int countAdmins = 0;
        
        for (Usuario usuario : mapaUsuarios.values()) {
            if (usuario instanceof Voluntario) {
                countVoluntarios++;
                System.out.println("Voluntario: " + usuario.getNome() + " | Email: " + usuario.getEmail());
            } else if (usuario instanceof Instituicao instituicao) {
                countInstituicoes++;
                System.out.println("Instituicao:  " + usuario.getNome() + 
                                 " | Email: " + usuario.getEmail() +
                                 " | Status: " + (instituicao.getCadastroAtivo() ? "Ativa" : "Inativa"));
            } else if (usuario instanceof Administrador) {
                countAdmins++;
                System.out.println("Administrador: " + usuario.getNome() + " | Email: " + usuario.getEmail());
            }
        }
        
        System.out.println("\nResumo: ");
        System.out.println("Voluntarios: " + countVoluntarios);
        System.out.println("Instituicoes: " + countInstituicoes);
        System.out.println("Administradores: " + countAdmins);
    }
    
    private static void verInstituicoesPendentes() {
        System.out.println("\n=== INSTITUICOES PENDENTES DE ATIVACAO === ");
        
        boolean temPendentes = false;
        for (Instituicao instituicao : instituicoes) {
            if (!instituicao.getCadastroAtivo()) {
                temPendentes = true;
                System.out.println("\n•  " + instituicao.getNome());
                System.out.println("CNPJ:  " + instituicao.getCnpj());
                System.out.println("Email: " + instituicao.getEmail());
                System.out.println("Telefone: " + instituicao.getTelefone());
                System.out.println("Area: " + instituicao.getAreaAtuacao());
                System.out.println("Local: " + instituicao.getCidade() + " - " + instituicao.getUf());
                System.out.println("Data de cadastro: " + instituicao.getDataCriacao());
            }
        }
        
        if (!temPendentes) {
            System.out.println("Nenhuma instituicao pendente de ativacao");
        }
    }
    
    
    private static void ativarInstituicoesPendentes() {
        System.out.println("\n=== ATIVAR INSTITUIÇCES PENDENTES === ");
        
        List<Instituicao> pendentes = new ArrayList<>();
        for (Instituicao instituicao : instituicoes) {
            if (!instituicao.getCadastroAtivo()) {
                pendentes.add(instituicao);
            }
        }
        
        if (pendentes.isEmpty()) {
            System.out.println("Nenhuma instituicao pendente de ativacao ");
            return;
        }
        
        for (int i = 0; i < pendentes.size(); i++) {
            Instituicao instituicao = pendentes.get(i);
            System.out.println("\n  " + (i + 1) + ". " + instituicao.getNome());
            System.out.println("CNPJ: " + instituicao.getCnpj());
            System.out.println("Email: " + instituicao.getEmail());
            System.out.println("Area: " + instituicao.getAreaAtuacao());
            System.out.println("Cidade: " + instituicao.getCidade() + " - " + instituicao.getUf());
        }
        
        System.out.print("\nDigite o número da instituicao para ativar (0 para cancelar): ");
        int escolha = scanner.nextInt();
        scanner.nextLine();
        
        if (escolha > 0 && escolha <= pendentes.size()) {
            Instituicao instituicao = pendentes.get(escolha - 1);
            instituicao.setCadastroAtivo(true);
            System.out.println("Instituição " + instituicao.getNome() + " ativada com sucesso!");
        }
    }
    
     private static void listarCatalogoInstituicoes() {
        System.out.println("\n=== CATALOGO DE INSTITUICOES ===");
        
        if (instituicoes.isEmpty()) {
            System.out.println("Nenhuma instituição cadastrada.");
            return;
        }
        
        int instituicoesAtivas = 0;
        for (int i = 0; i < instituicoes.size(); i++) {
            Instituicao instituicao = instituicoes.get(i);
            
            if (!instituicao.getCadastroAtivo()) {
                continue; // Pula instituições inativas no catálogo
            }
            
            instituicoesAtivas++;
            System.out.println("\n" + (instituicoesAtivas) + ". " + instituicao.getNome().toUpperCase());
            System.out.println("   CNPJ: " + instituicao.getCnpj());
            System.out.println("   Email: " + instituicao.getEmail());
            System.out.println("   Telefone: " + instituicao.getTelefone());
            System.out.println("   Area de Atuacao: " + instituicao.getAreaAtuacao());
            System.out.println("   LocalizaCao: " + instituicao.getCidade() + " - " + instituicao.getUf());
            System.out.println("   Endereço: " + instituicao.getEndereco() + ", " + instituicao.getBairro());
            
            // Projetos ativos
            List<Projeto> projetosAtivos = instituicao.getProjetosAtivos();
            System.out.println("   Projetos Ativos: " + projetosAtivos.size());
            for (Projeto projeto : projetosAtivos) {
                System.out.println("     - " + projeto.getNome() + " (" + projeto.getTipoServico() + ")");
                System.out.println("       Local: " + projeto.getLocal() + " | Duração: " + projeto.getDuracao());
            }
            
            // Pontos de coleta ativos
            List<PontoColeta> pontosAtivos = instituicao.getPontosColetaAtivos();
            System.out.println("   Pontos de Coleta Ativos: " + pontosAtivos.size());
            for (PontoColeta ponto : pontosAtivos) {
                System.out.println("     - " + ponto.getTipoDoacao() + 
                                 " | Qtd: " + ponto.getQuantidade() + 
                                 " | Prioridade: " + ponto.getPrioridade() +
                                 " | Prazo: " + ponto.getPrazo());
            }
        }
        
        if (instituicoesAtivas == 0) {
            System.out.println("Nenhuma instituicao ativa no momento.");
        } else {
            System.out.println("\nTotal de instituicoes ativas no catalogo: " + instituicoesAtivas);
        }
    }
    
    private static void listarTodosCadastros() {
        System.out.println("\n=== RELATORIO COMPLETO DO SISTEMA ===");
        
        System.out.println("\n--- INSTITUICOES (" + instituicoes.size() + ") ---");
        for (Instituicao instituicao : instituicoes) {
            System.out.println("• " + instituicao.getNome() + 
                             " | CNPJ: " + instituicao.getCnpj() +
                             " | Status: " + (instituicao.getCadastroAtivo() ? "ATIVA" : "INATIVA"));
        }
        
        System.out.println("\n--- VOLUNTARIOS (" + voluntarios.size() + ") ---");
        for (Voluntario voluntario : voluntarios) {
            System.out.println("• " + voluntario.getNome() + 
                             " | CPF: " + voluntario.getCpf() +
                             " | Contato visivel: " + (voluntario.isContatoVisivel() ? "SIM" : "NAO"));
        }
        
        System.out.println("\n--- ADMINISTRADORES (" + administradores.size() + ") ---");
        for (Administrador admin : administradores) {
            System.out.println("• " + admin.getNome() + " | Email: " + admin.getEmail());
        }
        
        System.out.println("\n--- PROJETOS (" + projetos.size() + ") ---");
        for (Projeto projeto : projetos) {
            System.out.println("• " + projeto.getNome() + " | " + projeto.getTipoServico() + " | Local: " + projeto.getLocal());
        }
        
        System.out.println("\n--- PONTOS DE COLETA (" + pontosColeta.size() + ") ---");
        for (PontoColeta ponto : pontosColeta) {
            System.out.println("• " + ponto.getTipoDoacao() + " | Qtd: " + ponto.getQuantidade() + " | Prioridade: " + ponto.getPrioridade());
        }
        
        System.out.println("\n--- TOTAL DE USUARIOS: " + usuarios.size() + " ---");
    }
    
}