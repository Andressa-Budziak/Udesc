/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit5TestClass.java to edit this template
 */
package Teste_dados;

import dados.Usuario;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;
import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;

/**
 *
 * @author andre
 */
public class UsuarioTest {
    
    public UsuarioTest() {
    }
    
    @BeforeAll
    public static void setUpClass() {
    }
    
    @AfterAll
    public static void tearDownClass() {
    }
    
    @BeforeEach
    public void setUp() {
    }
    
    @AfterEach
    public void tearDown() {
    }

    @Test
    public void testLoginCorreto() {
        Usuario user = new Usuario("Teste", "t@t.com", "123") {};
        assertTrue(user.login("123"));
    }

    @Test
    public void testLoginIncorreto() {
        Usuario user = new Usuario("Teste", "t@t.com", "123") {};
        assertFalse(user.login("999"));
    }

    @Test
    public void testAlterarSenha() {
        Usuario user = new Usuario("Teste", "t@t.com", "123") {};
        user.alterarSenha("nova");
        assertTrue(user.login("nova"));
    }

    @Test
    public void testDesativarConta() {
        Usuario user = new Usuario("Teste", "t@t.com", "123") {};
        user.desativarConta();
        assertFalse(user.login("123"));
    }
}
