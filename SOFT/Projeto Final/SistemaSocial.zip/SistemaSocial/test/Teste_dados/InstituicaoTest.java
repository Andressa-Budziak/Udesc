/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit5TestClass.java to edit this template
 */
package Teste_dados;

import dados.Instituicao;
import dados.PontoColeta;
import dados.Projeto;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;
import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
/**
 *
 * @author andre
 */
public class InstituicaoTest {
    
    public InstituicaoTest() {
    }
    
    @BeforeAll
    public static void setUpClass() {
    }
    
    @AfterAll
    public static void tearDownClass() {
    }
    
    @BeforeEach
    public void setUp() {
    }
    
    @AfterEach
    public void tearDown() {
    }
@Test
    public void testLoginInativo() {
        Instituicao inst = new Instituicao();
        assertFalse(inst.login());
    }

    @Test
    public void testLoginAtivo() {
        Instituicao inst = new Instituicao();
        inst.ativarConta();
        assertFalse(inst.login());
    }

    @Test
    public void testCadastrarProjeto() {
        Instituicao inst = new Instituicao();
        Projeto projeto = new Projeto(); // se existir na sua aplicação
        assertTrue(inst.cadastrarProjeto(projeto));
    }

    @Test
    public void testCadastrarPontoColeta() {
        Instituicao inst = new Instituicao();
        PontoColeta ponto = new PontoColeta(); // se existir
        assertTrue(inst.cadastrarPontoColeta(ponto));
    }
}
