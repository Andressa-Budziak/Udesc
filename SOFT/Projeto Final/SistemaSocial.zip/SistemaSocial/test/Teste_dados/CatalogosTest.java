/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit5TestClass.java to edit this template
 */
package Teste_dados;


import dados.Catalogo;
import dados.Instituicao;
import dados.PontoColeta;
import dados.Projeto;
import dados.Catalogo;
import dados.Instituicao;
import java.time.LocalDate;
import java.util.List;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.Test;
import static org.junit.Assert.*;
import org.junit.BeforeClass;




/**
 *
 * @author andre
 */
public class CatalogosTest {
    private Catalogo catalogo;
    private Instituicao instituicaoAtiva;
    private Instituicao instituicaoInativa;
    private Projeto projetoAtivo;
    private Projeto projetoInativo;
    private PontoColeta pontoAtivo;
    private PontoColeta pontoInativo;
    
    public CatalogosTest() {
        
    }
    
    @BeforeClass
    public static void setUpClass() {
        //System.out.println("Iniciando testes do Catálogo");
    }
    
    @AfterClass
    public static void tearDownClass() {
        //System.out.println("Finalizando testes do Catálogo");
    }
    
    @Before
    public void setUp() {
        catalogo = new Catalogo();
        
        instituicaoAtiva = new Instituicao("ONG Esperança", "ong@esperanca.org", "senha123", "12.345.678/0001-90");
        instituicaoAtiva.setCadastroAtivo(true);
        
        instituicaoInativa = new Instituicao("ONG Inativa", "inativa@ong.org", "senha456", "98.765.432/0001-10");
        instituicaoInativa.setCadastroAtivo(false);
        
        projetoAtivo = new Projeto("Projeto Ativo", "Descrição ativa", "Local ativo", "Tipo A");
        projetoAtivo.setAtivo(true);
        
        projetoInativo = new Projeto("Projeto Inativo", "Descrição inativa", "Local inativo", "Tipo B");
        projetoInativo.setAtivo(false); 
        
        
        pontoAtivo = new PontoColeta("Alimentos", 100, "ALTA", LocalDate.now().plusDays(30));
        pontoAtivo.setAtivo(true);
        
        pontoInativo = new PontoColeta("Roupas", 50, "MÉDIA", LocalDate.now().plusDays(15));
        pontoInativo.setAtivo(false);
        
        catalogo.adicionarInstituicao(instituicaoAtiva);
        catalogo.adicionarInstituicao(instituicaoInativa);
    }

    @After
    public void tearDown() {
        catalogo = null;
    }
    
    @Test
    public void testBuscarTodasInstituicoes() {
        //catalogo = new Catalogo();
        List<Instituicao> result = catalogo.buscarTodasInstituicoes();

        assertNotNull(result);
        assertEquals(2, result.size());
    }

    @Test
    public void testBuscarInstituicoesPorNome() {
        //catalogo = new Catalogo();
        List<Instituicao> result = catalogo.buscarInstituicoesPorNome("Teste");

        assertNotNull("Resultado não deve ser nulo", result);
        
    }

    @Test
    public void testBuscarProjetosAtivos() {
        //catalogo = new Catalogo();
        List<Projeto> result = catalogo.buscarProjetosAtivos();

        assertNotNull("Resultado de projetos não deve ser nulo", result);
        //assertTrue("Resultado de projetos deve estar vazio na implementação atual", result.isEmpty());
    }
    
    @Test
    public void testBuscarPontosColetaAtivos() {
        //catalogo = new Catalogo();
        List<PontoColeta> result = catalogo.buscarPontosColetaAtivos();

        assertNotNull("Resultado de pontos de coleta não deve ser nulo", result);
        
    }

    @Test
    public void testGetterSetterFiltros() {
        //catalogo = new Catalogo();
        catalogo.setFiltros("UF:SP");
        assertEquals("UF:SP", catalogo.getFiltros());
    }
    
}
