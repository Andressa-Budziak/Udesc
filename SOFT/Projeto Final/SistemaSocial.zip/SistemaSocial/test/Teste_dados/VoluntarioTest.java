/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit5TestClass.java to edit this template
 */
package Teste_dados;

import dados.Voluntario;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;
import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;

/**
 *
 * @author andre
 */
public class VoluntarioTest {
    
    public VoluntarioTest() {
    }
    
    @BeforeAll
    public static void setUpClass() {
    }
    
    @AfterAll
    public static void tearDownClass() {
    }
    
    @BeforeEach
    public void setUp() {
    }
    
    @AfterEach
    public void tearDown() {
    }

    @Test
    public void testLogin() {
        Voluntario v = new Voluntario("João", "joao@email.com", "123", "111.222.333-44");
        assertTrue(v.login());
    }

    @Test
    public void testAtualizarCadastro() {
        Voluntario v = new Voluntario();
        assertTrue(v.atualizarCadastro());
    }

    @Test
    public void testContatoVisivelPadrao() {
        Voluntario v = new Voluntario();
        assertFalse(v.isContatoVisivel());
    }

    @Test
    public void testAtualizarDisponibilidade() {
        Voluntario v = new Voluntario();
        assertTrue(v.atualizarDisponibilidade());
    }
}
