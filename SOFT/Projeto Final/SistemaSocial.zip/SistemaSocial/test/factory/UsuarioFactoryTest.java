/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit4TestClass.java to edit this template
 */
package factory;

import dados.Administrador;
import dados.Instituicao;
import dados.Usuario;
import dados.Voluntario;
import factory.UsuarioFactory;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;
import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;


/**
 *
 * @author andre
 */
public class UsuarioFactoryTest {
    
    public UsuarioFactoryTest() {
    }
    
    @BeforeClass
    public static void setUpClass() {
    }
    
    @AfterClass
    public static void tearDownClass() {
    }
    
    @Before
    public void setUp() {
    }
    

    /**
     * Test of criarUsuario method, of class UsuarioFactory.
     */
    @Test
    public void testCriarUsuario() {
       UsuarioFactory instance = new UsuarioFactory();

        Usuario result = instance.criarUsuario(
                "VOLUNTARIO",
                "João",
                "joao@email.com",
                "123"
        );
        
        assertNotNull(result);
        assertTrue(result instanceof Voluntario);
    }

    /**
     * Test of criarVoluntario method, of class UsuarioFactory.
     */
    @Test
    public void testCriarVoluntario() {
                UsuarioFactory instance = new UsuarioFactory();

        Voluntario result = instance.criarVoluntario(
                "Maria",
                "maria@email.com",
                "123",
                "111.222.333-44"
        );

        assertNotNull(result);
        assertEquals("Maria", result.getNome());
        assertEquals("maria@email.com", result.getEmail());
        assertEquals("111.222.333-44", result.getCpf());
        assertFalse(result.isContatoVisivel());
    }

    /**
     * Test of criarInstituicao method, of class UsuarioFactory.
     */
    @Test
    public void testCriarInstituicao() {
        UsuarioFactory instance = new UsuarioFactory();

        Instituicao result = instance.criarInstituicao(
                "ONG Teste",
                "ong@email.com",
                "123",
                "12.345.678/0001-90"
        );

        assertNotNull(result);
        assertEquals("ONG Teste", result.getNome());
        assertEquals("ong@email.com", result.getEmail());
        assertEquals("12.345.678/0001-90", result.getCnpj());
        assertFalse(result.getCadastroAtivo());
    }

    /**
     * Test of criarAdministrador method, of class UsuarioFactory.
     */
    @Test
    public void testCriarAdministrador() {
        UsuarioFactory instance = new UsuarioFactory();

        Administrador result = instance.criarAdministrador(
                "Admin",
                "admin@email.com",
                "123"
        );

        assertNotNull(result);
        assertEquals("Admin", result.getNome());
        assertEquals("admin@email.com", result.getEmail());
    }
    
}
