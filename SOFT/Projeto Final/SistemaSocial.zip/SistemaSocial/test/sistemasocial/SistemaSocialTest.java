/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit4TestClass.java to edit this template
 */
package sistemasocial;

import dados.Usuario;
import dados.Voluntario;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

public class SistemaSocialTest {
    
    public SistemaSocialTest() {
    }
    
    @BeforeClass
    public static void setUpClass() {
        System.out.println("Iniciando testes do SistemaSocial");
    }
    
    @AfterClass
    public static void tearDownClass() {
        System.out.println("Finalizando testes do SistemaSocial");
    }
    
    @Before
    public void setUp() {
    }
    
    @After
    public void tearDown() {
    }


    @Test
    public void testLoginUsuarioInvalido() {
        String email = "";
        String senha = "";

        boolean result = SistemaSocial.loginUsuario(email, senha);

        assertFalse(result); 
    }


    @Test
    public void testLoginUsuarioValido() {
        
        String nome = "Admin Teste";
        String email = "admin@email.com";
        String telefone = "11999999999";
        String senha = "123";

    SistemaSocial.cadastrarAdministradorTeste(nome, email, telefone, senha);

    boolean result = SistemaSocial.loginUsuario(email, senha);

    assertTrue(result);
    }

}
